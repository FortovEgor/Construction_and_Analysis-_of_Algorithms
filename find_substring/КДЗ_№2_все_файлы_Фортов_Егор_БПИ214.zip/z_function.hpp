uint64_t z_function (const std::string& p, const std::string& t);

